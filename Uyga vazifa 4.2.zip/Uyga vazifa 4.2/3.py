import os
os.system("cls")

class User:
    def __init__(self, name, username, followers,following):
        self.name = name
        self.username = username
        self.followers = followers
        self.following = following
    def follow(self, yangi_follower):
        if yangi_follower not in self.following:
            self.following.append(yangi_follower)
        else:
            print(f"Siz allaqachon {yangi_follower}ga obuna bolgansiz!")
    def unfollow(self,ochirish):
        if ochirish in self.following:
            self.following.remove(ochirish)
        else:
            print(f"Obuna bolganlaringiz orasida {ochirish} yoq!")
    def remove_follower(self, ochirish):
        if ochirish in self.followers:
            self.followers.remove(ochirish)
        else:
            print(f"Obunachilaringiz orasida {ochirish} yoq!")
u = User("Muhammadsodiq", "M@mUs0", ["soliha", "sakina", "Abdullo"], ["CR7","Neymar JR"])
u.follow("Raberto carles")
u.unfollow("Neymar JR")
u.remove_follower("soliha")
print(f"Name:{u.name}\nUsername:{u.username}\nObunachilari:{u.followers}\nObuna bolgan:{u.following}")