import os
os.system("cls")

class Restoran:
    def __init__(self,Ish_vaqt,menyu):
        self.ish_vaqti = Ish_vaqt
        self.menyu = [menyu]
    def add_food(self, yangi_ovqat):
        if yangi_ovqat not in self.menyu:
            self.menyu.append(yangi_ovqat)
        else:
            print("Bunday ovqat bor!")
    def get_work_time(self):
        print(self.ish_vaqti)

r = Restoran("8:00 - 20:00","Somsa")
r.add_food("Honim")
r.add_food("Osh")
print(r.menyu)
r.get_work_time()


