import os
os.system("cls")

class Phone:
    def __init__(self,brand, model, narx, yili):
        self.brand = brand
        self.model = model
        self.narx = narx
        self.yili = yili
    def update_price(self, yangi_narx):
        self.narx = yangi_narx
p = Phone("Samsung", "s24", 12000000,2025)
p.update_price(10000000)
print(f"{p.brand}\n{p.model}\n{p.narx}\n{p.yili}")