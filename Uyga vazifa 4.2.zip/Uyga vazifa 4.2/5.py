import os
import math
os.system("cls")

class Employee:
    def __init__(self,ismi, familiyasi, ishga_joylashgan_sanasi, lavozimi, maoshi, bonusi=0):
        self.ism = ismi
        self.familiya = familiyasi
        self.ish_joylashgan_sana = ishga_joylashgan_sanasi
        self.lavozim = lavozimi
        self.maosh = maoshi
        self.bonus = bonusi
    def set_bonus(self):
        if self.maosh < 10000000:
            self.bonus = self.maosh * 25 / 100
        else:
            print("Bonus ajratilmagan!")


e = Employee("Muhammadsodiq", "Mansurov", "23.05.2022", "Pragramist", 8000000)
e.set_bonus()

print("Oylik:",e.maosh)
print("Bonus:",e.bonus)

