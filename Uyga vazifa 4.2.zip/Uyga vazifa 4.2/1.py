import os
os.system("cls")

class Avto:
    def __init__(self,nomi, rangi, narxi, probegi, tezlig):
        self.nomi = nomi
        self.rangi = rangi
        self.narxi = narxi
        self.probegi = probegi
        self.tezlig = tezlig
    def update_probeg(self, yangi_probeg):
        self.probegi = yangi_probeg
    def update_narx(self, yangi_narx):
        self.narxi = yangi_narx

a = Avto("BMW", "Qora", 100000, 14000, 260)
a.update_probeg(10000)
a.update_narx(200000)
print(f"Nomi:{a.nomi}\nRangi:{a.rangi}\nNarxi:{a.narxi}\nProbeg:{a.probegi}\nTezlik:{a.tezlig}")


    

